'use strict';

/**
 * @ngdoc overview
 * @name portalDemoApp
 * @description
 * # portalDemoApp
 *
 * Main module of the application.
 */
angular
  .module('portalDemoApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngMessages',
    'ui.router',
    'ngSanitize',
    'ngTouch',
    'pascalprecht.translate'
  ]);

'use strict';

angular.module('portalDemoApp')
.constant('cookie',{
	life:30
})
.constant('constant',{
	'userinfo':'userinfo_constant'
});
/**
 * Created by Levana.Xue on 6/9/2015.
 */
'use strict';

angular.module('portalDemoApp')
.config(["$urlRouterProvider", "constant", function ($urlRouterProvider,constant) {

  $urlRouterProvider.otherwise('/index');

  $urlRouterProvider.rule(function ($injector, $location) {
       //what this function returns will be set as the $location.url
       console.log('------------------in rule --------------');

        var path = $location.path();
        if (path == "/main") {
            //instead of returning a new url string, I'll just change the $location.path directly so I don't have to worry about constructing a new url string and so a new state change is not triggered
            //$location.replace().path('/index');
        }
        // because we've returned nothing, no state change occurs
    });
}]);

'use strict';

angular.module('portalDemoApp')
.config(["$stateProvider", "$urlRouterProvider", function ($stateProvider,$urlRouterProvider) {
  var omnipotentState = {
      name:'info',
      url:'/info/{businessName}',
      templateUrl:function($stateParams){
        return 'views/info/'+$stateParams.businessName +'.html';
      },
      controller:function($scope){

      }
    };
  var loginState = {
      name:'login',
      url:'/index',
      templateUrl: 'views/login/login.html',
      controller: 'LoginCtrl'
    };
  var mainState = {
      name:'main',
      url:'/main',
      templateUrl: 'views/main/main.html',
      controller: 'mainCtrl',
      resolve:{
        testObj:function($http){
          return $http({method: 'post', url: 'api'})
               .then (function (data) {
                   return data;
               });
        },
        testObj2:function(){
          return "TEST TEST TEST ."
        },
        greeting:function($q, $timeout){
             var deferred = $q.defer();
             $timeout(function() {
                 deferred.resolve('Hello!');
             }, 1000);
             return deferred.promise;
         }
      },
      onEnter:function(testObj2){
        if(testObj2){
          // can't change value
        }
      }
    };
  $stateProvider
    .state(omnipotentState)
    .state(loginState)
    .state(mainState);
}]);

var translations_CN = {
  "INDEX_TITLE":"测试证券",
  "USER_NAME": "用户名",
  "USER_PASSWORD": "密码",
  "FORGET_PASSWORD": "忘记密码?",
  "LOGIN":{
  	"TITLE":"用户登入",
  	"LOGIN_BTN":"登入"
  },


  "LOGIN_SUCCESS":"登入成功！！"
}

var translations_EN ={
    "INDEX_TITLE":"Test Secuiy",
    "USER_NAME": "User Name",
    "USER_PASSWORD": "password",
    "FORGET_PASSWORD": "forget password?",
    "USER_NAME_EMPTY":"plz  enter your username.",
    "PASSWORD_EMPTY":"plz  enter your password.",
	"LOGIN":{
	  	"TITLE":"User login",
	  	"LOGIN_BTN":"Login"
	 },



    "LOGIN_SUCCESS":"Login success！！"
  }
/**
 * Created by Levana.Xue on 6/9/2015.
 */
'use strict';

angular.module('portalDemoApp')
.config(['$translateProvider',function ($translateProvider) {
	  $translateProvider.preferredLanguage('en');
  	  $translateProvider.useLoader('asyncLoaderLanguage');
}])
.factory('asyncLoaderLanguage', ["$q", "$timeout", function ($q, $timeout) {
  return function (options) {
    var deferred = $q.defer(),
        translations;
 
    if (options.key === 'en') {
      translations = translations_EN;
    } else {
      translations = translations_CN;
    }
 
    $timeout(function () {
      deferred.resolve(translations);
    }, 100);
 
    return deferred.promise;
  };
}]);
/**
 * Created by Levana.Xue on 6/9/2015.
 */
'use strict';

angular.module('portalDemoApp')
.run(['$rootScope','$urlRouter','constant','$state','dataStorageSvc',function ($rootScope,$urlRouter,constant,$state,dataStorageSvc) {

	$rootScope.$on('$stateChangeStart', 
		function(event, toState, toParams, fromState, fromParams){
			console.log('in $stateChangeStart...............');
		    // transitionTo() promise will be rejected with 
		    // a 'transition prevented' error

			if(toState != $state.get('login')){
				if (dataStorageSvc.session.get(constant.userinfo)){

			    }else{
			    	event.preventDefault();
			    	$state.go('login'); //redefine orientation
				    
				    //$urlRouter.sync(); // Continue with the update and state transition if logic allows
			    }
			}
		});
	$rootScope.$on('$stateNotFound', 
		function(event, unfoundState, fromState, fromParams){ 
		    /*console.log(unfoundState.to); 
		    console.log(unfoundState.toParams); 
		    console.log(unfoundState.options); */
		});
	$rootScope.$on('$stateChangeError', 
		function(event, toState, toParams, fromState, fromParams, error){
			//do something ...
		});
}]);
/**
 * Created by Levana.Xue on 6/11/2015.
 */


/**
 * Created by Levana.Xue on 6/11/2015.
 */
'use strict';

angular.module('portalDemoApp')
  .factory('httpInterceptor', ["$q", function($q) {
    return {
      'request': function(config) {
        return config;
      },
      'requestError': function(rejection) {
        return $q.reject(rejection);
      },
      'response': function(response) {
        return response;
      },
      'responseError': function(rejection) {
        console.error('request error .');
        return $q.reject(rejection);
      }
    };
}]);
angular.module('portalDemoApp')
  .config(["$httpProvider", function ($httpProvider) {
    $httpProvider.interceptors.push('httpInterceptor');
  }]);

'use strict';

angular.module('portalDemoApp')
.factory('dataStorageSvc',["$http", "$rootScope", function($http,$rootScope){
    var service = {
      session:(function(){
          var put = function(key, value){
              sessionStorage.setItem(key,value);
          },
          remove = function(key){
              sessionStorage.removeItem(key);
          },
          get =  function(key){
              if(key){
                  return sessionStorage.getItem(key) || null;
              }else{
                  return null;
              }
          },
          clear = function(){
            sessionStorage.clear();
          };
          return {
              put:put,
              remove:remove,
              get:get,
              clear:clear
          };
      })(),
      local:(function(){
          var put = function(key, value){
              localStorage.setItem(key,value);
          },
          remove = function(key){
              localStorage.removeItem(key);
          },
          get =  function(key){
              if(key){
                  return localStorage.getItem(key) || null;
              }else{
                  return null;
              }
          },
          clear = function(){
            sessionStorage.clear();
          };
          return {
              put:put,
              remove:remove,
              get:get,
              clear:clear
          };
      })()
    };
    return service;
  }]);

/**
 * Created by Levana.Xue on 6/11/2015.
 */
'use strict';

angular.module('portalDemoApp')
.factory('loginSvc',["$http", function($http){
    var service = {
      login:function(loginParams){
        return $http({
                method:'post',
                url:'LoginAction',
                params:loginParams
              }).then(function(result) {
                  return result.data;
              });
      }
    };
    return service;
  }]);

/**
 * Created by Levana.Xue on 6/9/2015.
 */
'use strict';

angular.module('portalDemoApp')
  .controller('LoginCtrl', ['$scope','$rootScope','loginSvc','$state','$translate','constant','dataStorageSvc', function ($scope,$rootScope,loginSvc,$state,$translate,constant,dataStorageSvc) {
    $scope.submitted = false;
    $scope.interacted = function(field) {
      return $scope.submitted || field.$dirty;
    };

    $scope.submit = function() {
      $scope.submitted = true;
      if($scope.loginForm.$valid){
       loginSvc.login($scope.userinfo).then(function(data){
         console.log(data);
         if(data[0].success){
            dataStorageSvc.session.put(constant.userinfo,data[0]);
            $state.go('main',{},{reload:true});
         }else{
           //login failed.
         }
       });
      }
    };

    $scope.changeLanguage = function (langKey) {
     $translate.use(langKey);
   };
  }]);

'use strict';

angular.module('portalDemoApp')
.controller('footCtrl',['$scope',function($scope){
	$scope.targetLink = 'https://code.angularjs.org/1.3.16/docs/api/ng/directive/ngInclude';
}]);
'use strict';

angular.module('portalDemoApp')
.controller('mainCtrl',["$scope", "testObj", "testObj2", "greeting", "$state", function($scope,testObj,testObj2,greeting,$state){
	console.log('in mainCtrl ...');
	console.log(testObj);
	console.log("data: "+testObj2);
	console.log('-------greeting------------');
	console.log(greeting);
	
	console.log("----$state----");
	console.log($state);
	$scope.$on('$viewContentLoaded', function(event){
		console.log("view loaded !!!");
	});
}]);