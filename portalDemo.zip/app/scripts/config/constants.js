'use strict';

angular.module('portalDemoApp')
.constant('cookie',{
	life:30
})
.constant('constant',{
	'userinfo':'userinfo_constant'
});