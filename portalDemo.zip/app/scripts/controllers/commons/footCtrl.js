'use strict';

angular.module('portalDemoApp')
.controller('footCtrl',['$scope',function($scope){
	$scope.targetLink = 'https://code.angularjs.org/1.3.16/docs/api/ng/directive/ngInclude';
}]);