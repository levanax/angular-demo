/**
 * Created by Levana.Xue on 6/9/2015.
 */
'use strict';

angular.module('portalDemoApp')
  .controller('LoginCtrl', ['$scope','$http', function ($scope,$http) {
    $scope.submitted = false;
    $scope.submit = function() {
      $scope.submitted = true;
      if($scope.loginForm.$valid){
        $http.post('/AngularTest/api', {username:$scope.username,password:$scope.password}).
          success(function(data) {
            // this callback will be called asynchronously
            // when the response is available
            console.log(data);
          });
      }
    };
    $scope.interacted = function(field) {
      return $scope.submitted || field.$dirty;
    };
  }]);
