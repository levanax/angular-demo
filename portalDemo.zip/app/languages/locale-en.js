var translations_EN ={
    "INDEX_TITLE":"Test Secuiy",
    "USER_NAME": "User Name",
    "USER_PASSWORD": "password",
    "FORGET_PASSWORD": "forget password?",
    "USER_NAME_EMPTY":"plz  enter your username.",
    "PASSWORD_EMPTY":"plz  enter your password.",
	"LOGIN":{
	  	"TITLE":"User login",
	  	"LOGIN_BTN":"Login"
	 },



    "LOGIN_SUCCESS":"Login success！！"
  }