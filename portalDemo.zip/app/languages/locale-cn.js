var translations_CN = {
  "INDEX_TITLE":"测试证券",
  "USER_NAME": "用户名",
  "USER_PASSWORD": "密码",
  "FORGET_PASSWORD": "忘记密码?",
  "LOGIN":{
  	"TITLE":"用户登入",
  	"LOGIN_BTN":"登入"
  },


  "LOGIN_SUCCESS":"登入成功！！"
}
